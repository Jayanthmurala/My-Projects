from django.contrib import admin
from page.models import To_do_data


# Register your models here.
admin.site.register(To_do_data)